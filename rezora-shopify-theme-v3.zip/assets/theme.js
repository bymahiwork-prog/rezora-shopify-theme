/* REZORA theme — small, dependency-free behaviours */
(() => {
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  document.documentElement.classList.remove('no-js');

  /* ---------- Quantity +/- buttons ---------- */
  document.addEventListener('click', (event) => {
    const button = event.target.closest('[data-qty]');
    if (!button) return;
    const input = button.parentElement.querySelector('input[type="number"]');
    if (!input) return;
    const min = parseInt(input.min || '0', 10);
    const current = parseInt(input.value, 10) || 0;
    input.value = Math.max(min, current + (button.dataset.qty === 'plus' ? 1 : -1));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  });

  /* ---------- Collection filters + sorting ---------- */
  const facetForm = document.getElementById('FacetForm');
  if (facetForm) {
    const submitFacets = () => {
      $$('input', facetForm).forEach((input) => {
        if (input.type === 'number' && input.value === '') input.disabled = true;
      });
      facetForm.submit();
    };
    document.addEventListener('change', (event) => {
      if (event.target.form === facetForm) submitFacets();
    });
    const drawer = $('[data-facets-drawer]');
    if (drawer && window.matchMedia('(min-width: 750px)').matches) drawer.open = true;
  }

  /* ---------- Load more (collection + search) ---------- */
  document.addEventListener('click', async (event) => {
    const button = event.target.closest('[data-load-more]');
    if (!button) return;
    event.preventDefault();
    button.setAttribute('aria-disabled', 'true');
    try {
      const response = await fetch(button.href);
      const doc = new DOMParser().parseFromString(await response.text(), 'text/html');
      const grid = $('[data-product-grid]');
      const incoming = $('[data-product-grid]', doc);
      if (grid && incoming) {
        $$(':scope > li:not([data-promo])', incoming).forEach((item) => grid.appendChild(item));
      }
      const wrapper = button.closest('.load-more');
      const fresh = $('.load-more', doc);
      if (wrapper && fresh) {
        wrapper.replaceWith(fresh);
      } else if (wrapper) {
        wrapper.remove();
      }
    } catch (error) {
      window.location.href = button.href;
    }
  });

  /* ---------- Product gallery ---------- */
  const showMedia = (gallery, mediaId) => {
    if (!gallery || !mediaId) return;
    const id = String(mediaId);
    if (!$(`[data-media-id="${id}"]`, gallery)) return;
    $$('[data-media-id]', gallery).forEach((el) => { el.hidden = el.dataset.mediaId !== id; });
    $$('[data-thumb]', gallery).forEach((el) => el.setAttribute('aria-pressed', String(el.dataset.thumb === id)));
  };
  $$('[data-gallery]').forEach((gallery) => {
    gallery.addEventListener('click', (event) => {
      const thumb = event.target.closest('[data-thumb]');
      if (thumb) showMedia(gallery, thumb.dataset.thumb);
    });
  });

  /* ---------- Variant picker ---------- */
  $$('[data-product-section]').forEach((section) => {
    const picker = $('[data-variant-picker]', section);
    const jsonEl = $('[data-product-json]', section);
    if (!picker || !jsonEl) return;
    const product = JSON.parse(jsonEl.textContent);
    const money = new Intl.NumberFormat('en-GB', { style: 'currency', currency: section.dataset.currency || 'GBP' });
    const gallery = $('[data-gallery]', section);

    picker.addEventListener('change', () => {
      const fieldsets = $$('fieldset', picker);
      const selected = fieldsets.map((fs) => {
        const checked = $('input:checked', fs);
        return checked ? checked.value : null;
      });
      fieldsets.forEach((fs, i) => {
        const label = $('[data-selected-value]', fs);
        if (label) label.textContent = selected[i] || '';
      });

      const variant = product.variants.find((v) => v.options.every((opt, i) => opt === selected[i]));
      const button = $('[data-add-button]', section);
      const idInput = $('form[action*="/cart/add"] input[name="id"]', section);

      if (!variant) {
        if (button) { button.disabled = true; button.textContent = 'Unavailable'; }
        return;
      }
      if (idInput) idInput.value = variant.id;
      if (button) {
        button.disabled = !variant.available;
        button.textContent = variant.available ? button.dataset.addLabel : 'Sold out';
      }
      const priceEl = $('[data-price]', section);
      if (priceEl) priceEl.textContent = money.format(variant.price / 100);
      const compareEl = $('[data-compare-price]', section);
      if (compareEl) {
        const onSale = variant.compare_at_price && variant.compare_at_price > variant.price;
        compareEl.hidden = !onSale;
        if (onSale) compareEl.textContent = money.format(variant.compare_at_price / 100);
      }
      if (variant.featured_media) showMedia(gallery, variant.featured_media.id);
      const url = new URL(window.location.href);
      url.searchParams.set('variant', variant.id);
      window.history.replaceState({}, '', url.toString());
    });
  });

  /* ---------- Cart: update quantities automatically ---------- */
  const cartForm = document.getElementById('CartForm');
  if (cartForm) {
    let timer;
    cartForm.addEventListener('change', (event) => {
      if (!event.target.matches('[data-cart-qty]')) return;
      clearTimeout(timer);
      timer = setTimeout(() => {
        let flag = $('input[name="update"]', cartForm);
        if (!flag) {
          flag = document.createElement('input');
          flag.type = 'hidden';
          flag.name = 'update';
          flag.value = '1';
          cartForm.appendChild(flag);
        }
        cartForm.submit();
      }, 400);
    });
  }

  /* ---------- Cart: discount codes ---------- */
  $$('[data-discount-form]').forEach((form) => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const code = $('input', form).value.trim();
      if (code) window.location.href = `/discount/${encodeURIComponent(code)}?redirect=/cart`;
    });
  });

  /* ---------- Product recommendations ---------- */
  $$('[data-recommendations]').forEach(async (el) => {
    try {
      const response = await fetch(el.dataset.url);
      const doc = new DOMParser().parseFromString(await response.text(), 'text/html');
      const fresh = $('[data-recommendations]', doc);
      if (fresh && fresh.innerHTML.trim()) {
        el.innerHTML = fresh.innerHTML;
        el.hidden = false;
      }
    } catch (error) {
      /* leave hidden */
    }
  });
})();
